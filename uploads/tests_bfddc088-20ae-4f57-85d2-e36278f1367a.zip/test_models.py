import sys, pytest
from pydantic import ValidationError
sys.path.append(".") # so we can find our local notebook related code 
# (i.e., your custom functions in routes) without needing to add it as a module path on the python search paths    

from main_file_location import create_note, get_note    # replace 'main_file_location' with actual location of file from where you are running this code  
# or if notebook is being run in Jupyter Notebooks then use __init__.py  (i.e., your custom functions without any import statement)    
from fastapi.exceptions import RequestValidationError

def test_create_note():
    # Happy path: A valid, non-empty note is created successfully with all the required attributes present and no errors raised  
    newNote = {"id": 1234567890,"content":"This is a sample content"}    
    assert create_note(newNote) == True # Assuming function returns boolean based on success of creation. If not, replace 'True' with actual return value  
                                              
def test_get_note():        
    noteId = 1234567890      
    retrievedNote = get_note(noteId)      # Assuming function returns the correct Note object based on successful retrieval. If not, replace 'retrievedNote' with actual return value  
                                              
def test_create_empty():    
  noteObj={}                  #Empty Object should raise ValidationError during creation   
  try:                         
      create_note(noteObj)      
  except RequestValidationError as e :         assert isinstance (e.status_code,400 )  
                                                      and "Invalid request" in str(e)          # Assertion for validation error    
                          
def test_get_None():          
    noteId = None              # A none object should raise ValidationError during retrieval 
                            try:                         create_note (noteId )            except RequestValidationError as e : assert isinstance(e.status_code,400) and "Invalid request" in str(e)      
                
def test_get_large():         # Large number might cause a validation error  for the same reason   
     noteID = 123456789        try:                     create_note (str(Note.id)) except RequestValidationError as e : assert isinstance (e .status code,  400) and "Invalid request" in str (E )  #Assertion for validation error   
```    ` ```         This should be done within a single markdown cell or it will not display correctly due to the way I've written this. If you need multiple cells separated by '##', please let me know!       Test Cases:      The test cases contain assertions which are used in pytest for testing purposes and ensure that certain conditions hold true during a given run of tests, effectively validating your code logic with edge scenarios to verify if the function is behaving as expected.