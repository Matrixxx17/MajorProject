import a
def use_hello():
    return a.hello() + '!'
