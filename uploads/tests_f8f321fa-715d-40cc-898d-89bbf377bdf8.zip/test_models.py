import pytest
from pydantic import ValidationError
# assuming your note model is defined in file models.py and available under 'Note' here 
sys.path.append(".") # append current directory to sys path, so we can load local modules from the same folder as our test script (currently executing)  
from routes import get_note    
# assuming your note model is defined in file models.py and available under 'Note' here 
sys.path.append(".") # append current directory to sys path, so we can load local modules from the same folder as our test script (currently executing)  
from routes import create_note    
# assuming your note model is defined in file models.py and available under 'Note' here 
sys.path.append(".") # append current directory to sys path, so we can load local modules from the same folder as our test script (currently executing)  
from models import Note